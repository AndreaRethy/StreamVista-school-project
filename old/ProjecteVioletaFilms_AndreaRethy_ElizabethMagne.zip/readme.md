# Creditos

header.jpg - Photo by [Tyson Moultrie](https://unsplash.com/@tysonmoultrie?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash) on [Unsplash](https://unsplash.com/photos/the-beatles-vinyl-record-sleeve-BQTHOGNHo08?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash)

popcorn.svgß - https://www.svgrepo.com/svg/246692/popcorn

cartoons.svg - https://www.svgrepo.com/svg/54324/cartoons

download.svg - https://www.svgrepo.com/svg/284833/download

mobile.svg - https://www.svgrepo.com/svg/291215/smartphone-mobile-phone
